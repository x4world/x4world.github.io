from opendbc.can.parser_pyx import CANParser, CANDefine  # pylint: disable=no-name-in-module, import-error
assert CANParser, CANDefine
